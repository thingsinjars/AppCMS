<?php
// $Id: ctoolsCachedPluginArray.class.php,v 1.2 2010/10/11 22:18:23 sdboyer Exp $
/**
 * @file
 * A cached plugin object that tests inheritence including.
 */

class ctoolsCachedPluginArray {}
