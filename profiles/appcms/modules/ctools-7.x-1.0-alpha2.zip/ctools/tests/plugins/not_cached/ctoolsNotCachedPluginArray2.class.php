<?php
// $Id: ctoolsNotCachedPluginArray2.class.php,v 1.1 2010/10/11 22:18:23 sdboyer Exp $
/**
 * @file
 * A cached plugin object that tests including.
 */

class ctoolsNotCachedPluginArray2 {}
